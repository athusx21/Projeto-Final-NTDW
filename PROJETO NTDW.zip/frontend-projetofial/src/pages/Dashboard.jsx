// src/pages/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { api } from "../../services/api";
import { Link, useLocation } from "react-router-dom";
import "./Dashboard.css";

const formatDate = (d) => (d ? new Date(d).toLocaleDateString() : "—");

const Dashboard = () => {
  const [resumo, setResumo] = useState({
    totalProjetos: 0,
    totalPremios: 0,
    totalAvaliadores: 0,
    totalAutores: 0,
  });
  const [detalhes, setDetalhes] = useState([]);
  const [tipoDetalhes, setTipoDetalhes] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();

  // Carrega cards de resumo
  useEffect(() => {
    const carregarResumo = async () => {
      try {
        setLoading(true);
        const data = await api.getResumo();
        setResumo({
          totalProjetos: data?.totalProjetos ?? 0,
          totalPremios: data?.totalPremios ?? 0,
          totalAvaliadores: data?.totalAvaliadores ?? 0,
          totalAutores: data?.totalAutores ?? 0,
        });
      } catch (err) {
        console.error(err);
        setError("Erro ao carregar o resumo.");
      } finally {
        setLoading(false);
      }
    };
    carregarResumo();
  }, []);

  const isActive = (path) => location.pathname === path;

  const mapProjeto = (p) => ({
    id: p.id,
    titulo: p.titulo,
    autores: Array.isArray(p.autores) ? p.autores.map((a) => a.nome).join(", ") : "—",
    areaTematica: p.areaTematica ?? "—",
    dataEnvio: formatDate(p.dataEnvio),
    mediaNota: p.mediaNota ?? "—",
    avaliado: p.avaliado ? "Sim" : "Não",
  });

  const mapAvaliacao = (a) => ({
    id: a.id,
    projeto: a.projeto?.titulo ?? `#${a.projeto?.id ?? ""}`,
    avaliador: a.avaliador?.nome ?? `#${a.avaliador?.id ?? ""}`,
    nota: a.nota,
    parecer: a.parecer,
    dataAvaliacao: formatDate(a.dataAvaliacao),
  });

  const carregarDetalhes = async (tipo) => {
    try {
      setError(null);
      setLoading(true);
      setTipoDetalhes(tipo);

      let response = [];
      switch (tipo) {
        case "premios":
          response = await api.getPremios();
          break;
        case "autores":
          response = await api.getAutores();
          break;
        case "projetos":
          response = await api.getProjetos();
          response = (response || []).map(mapProjeto);
          break;
        case "projetos-avaliados":
          response = await api.getProjetosAvaliados();
          response = (response || []).map(mapProjeto);
          break;
        case "projetos-nao-avaliados":
          response = await api.getProjetosNaoAvaliados();
          response = (response || []).map(mapProjeto);
          break;
        case "projetos-vencedores":
          response = await api.getProjetosVencedores();
          response = (response || []).map(mapProjeto);
          break;
        case "avaliadores":
          response = await api.getAvaliadores();
          break;
        case "avaliacoes":
          response = await api.getAvaliacoes();
          response = (response || []).map(mapAvaliacao);
          break;
        default:
          response = [];
      }

      setDetalhes(Array.isArray(response) ? response : [response]);
    } catch (err) {
      console.error(err);
      setError(`Erro ao carregar detalhes de ${tipo}.`);
      setDetalhes([]);
    } finally {
      setLoading(false);
    }
  };

  const limparDetalhes = () => {
    setDetalhes([]);
    setTipoDetalhes(null);
  };

  const renderizarTabela = () => {
    if (!detalhes?.length) return <p className="no-data">Nenhum dado encontrado</p>;
    const sample = detalhes[0] || {};
    const colunas = Object.keys(sample);

    return (
      <table className="details-table">
        <thead>
          <tr>{colunas.map((c) => <th key={c}>{c}</th>)}</tr>
        </thead>
        <tbody>
          {detalhes.map((item, idx) => (
            <tr key={idx}>
              {colunas.map((c) => (
                <td key={`${idx}-${c}`}>
                  {typeof item[c] === "object" ? JSON.stringify(item[c]) : (item[c] ?? "—")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div className="dashboard-container">
      <aside className="sidebar">
        <div className="sidebar-header">
          <h2 className="sidebar-title">Painel Admin</h2>
        </div>

        <nav className="sidebar-nav">
          <Link to="/" className={`sidebar-link ${isActive("/") ? "active" : ""}`}>📊 Dashboard</Link>
          <Link to="/cadastro-premio" className={`sidebar-link ${isActive("/cadastro-premio") ? "active" : ""}`}>🏆 Cadastrar Prêmio</Link>
          <Link to="/cadastro-autor" className={`sidebar-link ${isActive("/cadastro-autor") ? "active" : ""}`}>✍️ Cadastrar Autor</Link>
          <Link to="/cadastro-avaliador" className={`sidebar-link ${isActive("/cadastro-avaliador") ? "active" : ""}`}>👨‍⚖️ Cadastrar Avaliador</Link>
          <Link to="/envio-projeto" className={`sidebar-link ${isActive("/envio-projeto") ? "active" : ""}`}>📤 Enviar Projeto</Link>
          <Link to="/avaliacao-projeto" className={`sidebar-link ${isActive("/avaliacao-projeto") ? "active" : ""}`}>⭐ Avaliar Projeto</Link>
          <Link to="/listagem-projetos" className={`sidebar-link ${isActive("/listagem-projetos") ? "active" : ""}`}>📋 Listar Projetos</Link>
        </nav>

        <div className="sidebar-footer">
          <p className="footer-text">Sistema de Gerenciamento v1.0</p>
        </div>
      </aside>

      <main className="main-content">
        <div className="content-header">
          <h1 className="main-title">📊 Dashboard</h1>
        </div>

        <div className="content-area">
          {error ? (
            <div className="error-message">
              <p>{error}</p>
              <button onClick={() => window.location.reload()}>Tentar novamente</button>
            </div>
          ) : loading ? (
            <div className="loading-container">
              <div className="loading-spinner" />
              <p>Carregando dados...</p>
            </div>
          ) : tipoDetalhes ? (
            <div className="details-view">
              <div className="details-header">
                <h2>Detalhes de {tipoDetalhes}</h2>
                <button onClick={limparDetalhes}>← Voltar</button>
              </div>
              {renderizarTabela()}
            </div>
          ) : (
            <div className="cards-container">
              <div className="stat-card" onClick={() => carregarDetalhes("premios")}>🏆 Prêmios: {resumo.totalPremios}</div>
              <div className="stat-card" onClick={() => carregarDetalhes("autores")}>✍️ Autores: {resumo.totalAutores}</div>
              <div className="stat-card" onClick={() => carregarDetalhes("projetos")}>📁 Projetos: {resumo.totalProjetos}</div>
              <div className="stat-card" onClick={() => carregarDetalhes("projetos-avaliados")}>✅ Projetos Avaliados</div>
              <div className="stat-card" onClick={() => carregarDetalhes("projetos-nao-avaliados")}>📂 Projetos Não Avaliados</div>
              <div className="stat-card" onClick={() => carregarDetalhes("projetos-vencedores")}>🏅 Vencedores</div>
              <div className="stat-card" onClick={() => carregarDetalhes("avaliadores")}>👨‍⚖️ Avaliadores: {resumo.totalAvaliadores}</div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
