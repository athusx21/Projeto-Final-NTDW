// AvaliadorCadastro.jsx
import React, { useState } from 'react';
import { api } from '../../services/api';
import LayoutPadrao from "../Dashboard/LayoutPadrao";

const AvaliadorCadastro = () => {
    const [formData, setFormData] = useState({
        nome: '',
        email: '',
        telefone: '',
        especialidade: '',
        instituicao: ''
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await api.cadastrarAvaliador(formData);
        alert('Avaliador cadastrado com sucesso!');
        setFormData({
            nome: '',
            email: '',
            telefone: '',
            especialidade: '',
            instituicao: ''
        });
    };

    return (
        <LayoutPadrao>
            <div>
                <h1>Cadastrar Avaliador</h1>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Nome:</label>
                        <input
                            type="text"
                            name="nome"
                            value={formData.nome}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Email:</label>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Telefone:</label>
                        <input
                            type="text"
                            name="telefone"
                            value={formData.telefone}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Especialidade:</label>
                        <input
                            type="text"
                            name="especialidade"
                            value={formData.especialidade}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Instituição:</label>
                        <input
                            type="text"
                            name="instituicao"
                            value={formData.instituicao}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <button type="submit">Cadastrar</button>
                </form>
            </div>
        </LayoutPadrao>
    );
};

export default AvaliadorCadastro;
