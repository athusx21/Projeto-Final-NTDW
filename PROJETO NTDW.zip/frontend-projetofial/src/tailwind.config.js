/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Adicione o caminho dos seus componentes
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
