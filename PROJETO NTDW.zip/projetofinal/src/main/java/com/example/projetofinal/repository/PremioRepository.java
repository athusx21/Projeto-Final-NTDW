package com.example.projetofinal.repository;


import com.example.projetofinal.model.Premio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PremioRepository extends JpaRepository<Premio, Long> {
}
