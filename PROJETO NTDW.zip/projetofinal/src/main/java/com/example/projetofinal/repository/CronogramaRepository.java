package com.example.projetofinal.repository;

import com.example.projetofinal.model.Cronograma;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CronogramaRepository extends JpaRepository<Cronograma, Long> {
}
